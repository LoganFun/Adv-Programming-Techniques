/*
Author: Ziwei Li
Class: ECE6122
Last Date Modified: 09092023
Description:
Lab1
*/

#ifndef ECE_POINTCHARGE_H_
#define ECE_POINTCHARGE_H_

class ECE_PointCharge
{
protected:
	double x; // x-coordinate.
	double y; // y-coordinate.
	double z; // z-coordinate.
	double q; // charge of the point	

public:
	ECE_PointCharge(double x, double y, double z, double q) : x{ x }, y{ y }, z{ z }, q{ q } {};
	void setLocation(double x, double y, double z);
	void setCharge(double q);
};

#endif 
