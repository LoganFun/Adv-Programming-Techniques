/*
Author: Ziwei Li
Class: ECE6122
Last Date Modified: 09092023
Description:
Lab1
*/

#ifndef ECE_ELECTRICFIELD_H_
#define ECE_ELECTRICFIELD_H_

#include "ECE_PointCharge.h"

#define CONST_COULOMB_VAL			(9000.0)	/* (um^2/C^2) */

class ECE_ElectricField : public ECE_PointCharge
{
protected:
	double Ex; 
	double Ey;
	double Ez;

public:
	ECE_ElectricField(double x, double y, double z, double q) : ECE_PointCharge(x, y, z, q) {};
	void computeFieldAt(double x, double y, double z); 
	void getElectricField(double& Ex, double& Ey, double& Ez);
};

#endif 

