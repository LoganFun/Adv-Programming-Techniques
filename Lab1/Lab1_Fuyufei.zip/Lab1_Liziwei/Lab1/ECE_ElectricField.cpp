/*
Author: Ziwei Li
Class: ECE6122
Last Date Modified: 09092023
Description:
Lab1
*/

#include <math.h>
#include "ECE_ElectricField.h"

void ECE_ElectricField::computeFieldAt(double x, double y, double z)
{
	double x_dist;
	double y_dist;
	double z_dist;
	double r_dist_sq;
	double r_dist;
	double e_abs;

	this->Ex = 0.0;
	this->Ey = 0.0;
	this->Ez = 0.0;

	x_dist = x - this->x;
	y_dist = y - this->y;
	z_dist = z - this->z;

	r_dist_sq = x_dist * x_dist + y_dist * y_dist + z_dist * z_dist;

	if (r_dist_sq != 0.0)
	{
		r_dist = sqrt(r_dist_sq);
		e_abs = CONST_COULOMB_VAL * this->q / r_dist_sq;

		this->Ex = e_abs * x_dist / r_dist;
		this->Ey = e_abs * y_dist / r_dist;
		this->Ez = e_abs * z_dist / r_dist;
	}

	return; 
}

void ECE_ElectricField::getElectricField(double& Ex, double& Ey, double& Ez)
{
	Ex = this->Ex; 
	Ey = this->Ey; 
	Ez = this->Ez;

	return; 
}
