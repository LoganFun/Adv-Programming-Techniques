/*
Author: Ziwei Li
Class: ECE6122
Last Date Modified: 09092023
Description:
Lab1
*/

#include "ECE_PointCharge.h"

void ECE_PointCharge::setLocation(double x, double y, double z)
{
	this->x = x; 
	this->y = y; 
	this->z = z;

	return;
}

void ECE_PointCharge::setCharge(double q)
{
	this->q = q; 

	return; 
}
