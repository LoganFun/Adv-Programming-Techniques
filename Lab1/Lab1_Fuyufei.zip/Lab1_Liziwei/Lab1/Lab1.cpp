﻿
/*
Author: Ziwei Li
Class: ECE6122
Last Date Modified: 09092023
Description:
Lab1
*/

#include <iostream>
#include <assert.h>
#include <math.h>
#include <limits>
#include <thread>
#include <atomic>

#include "ECE_ElectricField.h"

typedef struct
{
    int dim_n;
    int dim_m;
    double dot_dist_on_x;
    double dot_dist_on_y;
    double dot_charge;
}elec_field_arr_cfg_s;

typedef struct
{
    double loc_x;
    double loc_y;
    double loc_z;
}calc_input_s;

typedef struct
{
    std::atomic<bool> is_ready;
    std::atomic<bool> is_finished;
    ECE_ElectricField* p_elec_field;
    int num_elec_field;
    calc_input_s calc_input;
}thread_arg_s;

static void format_to_between_one_and_ten(double val, double& val_betw_one_to_ten, int& num_trailing_zero)
{
    num_trailing_zero = 0;

    if (val != 0.0)
    {
        while (val >= 10.0 || val <= -10.0)
        {
            val /= 10.0;
            num_trailing_zero++;
        }

        while (val < 1.0 && val > -1.0)
        {
            val *= 10.0;
            num_trailing_zero--;
        }
    }

    val_betw_one_to_ten = val; 

    return;
}

static void elec_field_arr_get_cfg(int& err, elec_field_arr_cfg_s& cfg)
{
    if (err == 0)
    {
        cfg.dim_n = 0;
        cfg.dim_m = 0;

        std::cout << "Please enter the number of rows and columns in the N x M array: ";
        if (!(std::cin >> cfg.dim_n))
        {
            std::cout << "Failed to get N.\n";
        }

        if (!(std::cin >> cfg.dim_m))
        {
            std::cout << "Failed to get M.\n";
        }

        if (cfg.dim_m < 1 || cfg.dim_n < 1)
        {
            std::cout << "Invalid N or M.\n";
            err |= 0xFFFFFFFF;
        }

        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    if (err == 0)
    {
        cfg.dot_dist_on_x = 0.0;
        cfg.dot_dist_on_y = 0.0;

        std::cout << "Please enter the x and y separation distances in meters : ";
        if (!(std::cin >> cfg.dot_dist_on_x))
        {
            std::cout << "Failed to get distance on x.\n";
        }

        if (!(std::cin >> cfg.dot_dist_on_y))
        {
            std::cout << "Failed to get distance on y.\n";
        }

        if (cfg.dot_dist_on_x <= 0.0 || cfg.dot_dist_on_y <= 0.0)
        {
            std::cout << "Invalid distance of x or y.\n";
            err |= 0xFFFFFFFF;
        }

        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    if (err == 0)
    {
        cfg.dot_charge = 0.0;

        std::cout << "Please enter the common charge on the points in micro C : ";
        if (!(std::cin >> cfg.dot_charge))
        {
            std::cout << "Failed to get charge.\n";
            err |= 0xFFFFFFFF;
        }

        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    return;
}

static void get_calc_input(int& err, calc_input_s& input)
{
    if (err == 0)
    {
        std::cout << "Please enter the location in space to determine the electric field (x y z) in meters: ";
        if (!(std::cin >> input.loc_x) || !(std::cin >> input.loc_y) || !(std::cin >> input.loc_z))
        {
            std::cout << "Failed to get location of x or y or z.\n";
            err |= 0xFFFFFFFF;
        }
        else
        {
            std::cout << "The electric field at(" << input.loc_x << ", " << input.loc_y << ", " << input.loc_z << ") in V / m is\n";
        }

        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    return;
}

static void elec_field_arr_init(int& err, ECE_ElectricField** p_elec_field_arr, elec_field_arr_cfg_s const& elec_field_arr_cfg)
{
    int dim_n_idx, dim_m_idx;
    double new_loc_x, new_loc_y, new_loc_z, new_loc_x_offs, new_loc_y_offs;
    ECE_ElectricField* elec_field_arr = NULL;

    assert(p_elec_field_arr != NULL);

    if (err == 0)
    {
        elec_field_arr = (ECE_ElectricField*)calloc(elec_field_arr_cfg.dim_m * elec_field_arr_cfg.dim_n, sizeof(ECE_ElectricField));

        if (elec_field_arr == NULL)
        {
            err |= 0xFFFFFFFF;
        }
    }

    if (err == 0)
    {
        /* Distribute electric charges across 2-D dimension and around center */
        /* Each charge is separated by fixed distance */
        /* When number of charge is even, shift charge by half distance for centering origin */

        new_loc_x_offs = 0.0;
        new_loc_y_offs = 0.0;
        if (elec_field_arr_cfg.dim_n % 2 == 0)
        {
            new_loc_x_offs = 0.5 * elec_field_arr_cfg.dot_dist_on_x;
        }
        if (elec_field_arr_cfg.dim_m % 2 == 0)
        {
            new_loc_y_offs = 0.5 * elec_field_arr_cfg.dot_dist_on_y;
        }

        for (dim_n_idx = 0; dim_n_idx < elec_field_arr_cfg.dim_n; dim_n_idx++)
        {
            for (dim_m_idx = 0; dim_m_idx < elec_field_arr_cfg.dim_m; dim_m_idx++)
            {
                new_loc_x = new_loc_x_offs + (dim_n_idx - elec_field_arr_cfg.dim_n / 2) * elec_field_arr_cfg.dot_dist_on_x;
                new_loc_y = new_loc_y_offs + (dim_m_idx - elec_field_arr_cfg.dim_m / 2) * elec_field_arr_cfg.dot_dist_on_y;
                new_loc_z = 0.0;

                new (&elec_field_arr[dim_n_idx * elec_field_arr_cfg.dim_m + dim_m_idx]) ECE_ElectricField(new_loc_x, new_loc_y, new_loc_z, elec_field_arr_cfg.dot_charge);
            }
        }

        *p_elec_field_arr = elec_field_arr;
    }

    return;
}

static void elec_field_arr_destroy(int& err, ECE_ElectricField* elec_field_arr, elec_field_arr_cfg_s const& elec_field_arr_cfg)
{
    (void)elec_field_arr_cfg;

    if (err == 0)
    {
        free(elec_field_arr);
    }

    return;
}

static void elec_field_arr_print(int& err, ECE_ElectricField* elec_field_arr, elec_field_arr_cfg_s const& elec_field_arr_cfg)
{
    int elec_field_idx;
    int num_trailing_zero;
    double val_betw_one_and_ten;
    double e_x, e_y, e_z, e_x_sum, e_y_sum, e_z_sum, e_sum_abs;

    if (err == 0)
    {
        num_trailing_zero = 0;
        val_betw_one_and_ten = 0.0;
        e_x = 0.0;
        e_y = 0.0;
        e_z = 0.0;
        e_x_sum = 0.0;
        e_y_sum = 0.0;
        e_z_sum = 0.0;
        e_sum_abs = 0.0;

        for (elec_field_idx = 0; elec_field_idx < elec_field_arr_cfg.dim_m * elec_field_arr_cfg.dim_n; elec_field_idx++)
        {
            elec_field_arr[elec_field_idx].getElectricField(e_x, e_y, e_z);

            e_x_sum += e_x;
            e_y_sum += e_y;
            e_z_sum += e_z;
        }

        e_sum_abs = sqrt(e_x_sum * e_x_sum + e_y_sum * e_y_sum + e_z_sum * e_z_sum);

        format_to_between_one_and_ten(e_x_sum, val_betw_one_and_ten, num_trailing_zero);
        std::cout << "Ex = " << val_betw_one_and_ten << " * 10^" << num_trailing_zero << "\n";
        format_to_between_one_and_ten(e_y_sum, val_betw_one_and_ten, num_trailing_zero);
        std::cout << "Ey = " << val_betw_one_and_ten << " * 10^" << num_trailing_zero << "\n";
        format_to_between_one_and_ten(e_z_sum, val_betw_one_and_ten, num_trailing_zero);
        std::cout << "Ez = " << val_betw_one_and_ten << " * 10^" << num_trailing_zero << "\n";
        format_to_between_one_and_ten(e_sum_abs, val_betw_one_and_ten, num_trailing_zero);
        std::cout << "|E| = " << val_betw_one_and_ten << " * 10^" << num_trailing_zero << "\n";
    }

    return; 
}

static void elec_field_arr_run(int& err, ECE_ElectricField* elec_field_arr, int num_elec_field, calc_input_s const& calc_input)
{
    int elec_field_idx;

    if (err == 0)
    {
        for (elec_field_idx = 0; elec_field_idx < num_elec_field; elec_field_idx++)
        {
            elec_field_arr[elec_field_idx].computeFieldAt(calc_input.loc_x, calc_input.loc_y, calc_input.loc_z);
        }
    }

    return; 
}


static void* thread_func(void* p_arg)
{
    int err = 0;
    thread_arg_s* p_thread_arg;

    p_thread_arg = (thread_arg_s*)p_arg;

    while (err == 0 && p_thread_arg ->is_finished == false)
    {
        if (p_thread_arg->is_ready == false)
        {
            std::this_thread::yield();
        }
        else
        {
            elec_field_arr_run(err, p_thread_arg->p_elec_field, p_thread_arg->num_elec_field, p_thread_arg->calc_input);

            p_thread_arg->is_ready = false;
        }
    };

    return NULL;
}

int main()
{
    auto const NUM_THRAED_MINUS_ONE = std::thread::hardware_concurrency() - 1;
    int err = 0;
    int thread_cnt = 0;
    int thread_idx = 0;
    int elec_field_idx;
    int num_elec_field = 0;
    int num_elec_field_per_thread = 0;
    std::string s;
    calc_input_s calc_input;
    elec_field_arr_cfg_s elec_field_arr_cfg;
    thread_arg_s* thread_arg_arr = NULL;
    std::thread* thread_arr = NULL; 
    ECE_ElectricField* elec_field_arr = NULL;

    if (err == 0)
    {
        std::cout << "Your computer supports " << (NUM_THRAED_MINUS_ONE + 1) << " concurrent threads.\n";

        if (NUM_THRAED_MINUS_ONE == 0)
        {
            assert(0);
            err |= 0xFFFFFFFF;
        }
    }

    /**************************************************************************/
    /*************************** BEGIN INITIALIZING ***************************/
    /**************************************************************************/

	if (err == 0)
	{
		elec_field_arr_get_cfg(err, elec_field_arr_cfg);
		elec_field_arr_init(err, &elec_field_arr, elec_field_arr_cfg);
		num_elec_field = elec_field_arr_cfg.dim_n * elec_field_arr_cfg.dim_m;
		num_elec_field_per_thread = NUM_THRAED_MINUS_ONE == 0 ? 0 : num_elec_field / NUM_THRAED_MINUS_ONE;
	}
	
    if (err == 0)
    {
        thread_arg_arr = (thread_arg_s*)calloc(NUM_THRAED_MINUS_ONE, sizeof(thread_arg_s));
        if (thread_arg_arr == NULL)
        {
            assert(0);
            err |= 0xFFFFFFFF;
        }
        else
        {
			elec_field_idx = 0;
            for (thread_idx = 0; thread_idx < NUM_THRAED_MINUS_ONE; thread_idx++)
            {
                thread_arg_arr[thread_idx].is_ready = false; 
                thread_arg_arr[thread_idx].is_finished = false;
				thread_arg_arr[thread_idx].p_elec_field = &elec_field_arr[elec_field_idx];
				thread_arg_arr[thread_idx].num_elec_field = num_elec_field_per_thread;
				
				elec_field_idx += num_elec_field_per_thread;
            }
        }
    }

    if (err == 0)
    {
        thread_arr = (std::thread *)calloc(NUM_THRAED_MINUS_ONE, sizeof(std::thread));
        if (thread_arr == NULL)
        {
            assert(0);
            err |= 0xFFFFFFFF;
        }
        else
        {
            for (thread_idx = 0; thread_idx < NUM_THRAED_MINUS_ONE; thread_idx++)
            {
                new (&thread_arr[thread_idx]) std::thread(thread_func, &thread_arg_arr[thread_idx]);
            }
        }
    }



    /**************************************************************************/
    /***************************** BEGIN RUNNING ******************************/
    /**************************************************************************/

    while (err == 0)
    {
        do
        {
            err = 0;
            get_calc_input(err, calc_input);
        } while (err != 0);

        auto clk_begin = std::chrono::high_resolution_clock::now(); 

        
        for (thread_idx = 0; thread_idx < NUM_THRAED_MINUS_ONE && err == 0; thread_idx++)
        {		
            thread_arg_arr[thread_idx].calc_input = calc_input;
            thread_arg_arr[thread_idx].is_ready = true; 
        }

        if (err == 0)
        {
            elec_field_arr_run(err, &elec_field_arr[elec_field_idx], num_elec_field - elec_field_idx, calc_input);
        }

        /* Synchronize every thread completion */
        if (err == 0)
        {
            do
            {
                thread_cnt = 0;
                for (thread_idx = 0; thread_idx < NUM_THRAED_MINUS_ONE; thread_idx++)
                {
                    if (thread_arg_arr[thread_idx].is_ready == false)
                    {
                        thread_cnt++;
                    }
					else
					{
						std::this_thread::yield();
					}
                }
            } while (thread_cnt < NUM_THRAED_MINUS_ONE);
        }

        auto clk_end = std::chrono::high_resolution_clock::now();
        auto clk_taken = std::chrono::duration_cast<std::chrono::microseconds>(clk_end - clk_begin);

        elec_field_arr_print(err, elec_field_arr, elec_field_arr_cfg);

        if (err == 0)
        {
            std::cout << "The calculation took " << clk_taken.count() << " microsec!\n";
            std::cout << "Do you want to enter a new location (Y/N)?";
            std::cin >> s;
            if (s.at(0) != 'Y' && s.at(0) != 'y')
            {
                for (thread_idx = 0; thread_idx < NUM_THRAED_MINUS_ONE; thread_idx++)
                {
                    thread_arg_arr[thread_idx].is_finished = true; 
                }

                break;
            }

            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }

    std::cout << "Bye!\n";

    free(thread_arr);
    free(thread_arg_arr);
    elec_field_arr_destroy(err, elec_field_arr, elec_field_arr_cfg);

    return err;
}
