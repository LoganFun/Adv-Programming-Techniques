/*
*Author: Zilong Fan(GTID:903919944);
*Class:ECE6122A;
*Last Data Modified:0904-2023
*
*Description: Output the text to terminal screen
*
*/

#include<iostream>

using namespace std;
/*
* The goal is to output correct characters with \
*/
int main() 
{
	cout << "My name is: Zilong Fan" << endl;
	cout << "This (\") is a double quote." << endl;
	cout << "This (\') is a single quote." << endl;
	cout << "This (\\) is a backslash." << endl;
	cout << "This (/) is a forward slash." << endl;
	return 0;
};